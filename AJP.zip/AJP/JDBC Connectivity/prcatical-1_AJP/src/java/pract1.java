

import java.sql.*;  
import java.util.Scanner;
public class pract1 {
    public static void main(String[] args) {   
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Username: ");
        String username = sc.nextLine();
        System.out.print("Enter Password: ");
        String password = sc.nextLine();
        String url = "jdbc:mysql://localhost:3306/ajp"; 
        String dbUsername = "root"; 
        String dbPassword = ""; 
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";        
        try {
            Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);        
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                System.out.println("Successful Login");
            } else {
                System.out.println("Invalid Username or Password");
            }
            rs.close();
            pst.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

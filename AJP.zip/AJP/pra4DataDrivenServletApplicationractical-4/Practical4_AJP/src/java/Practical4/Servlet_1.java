package Practical4;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet_1")
public class Servlet_1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Servlet_1() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        process(request, response);
    }

    void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String userName = request.getParameter("uid");
        String passWord = request.getParameter("pwd");
        PrintWriter out = response.getWriter();

        try {
          
          DriverManager.registerDriver(new com.mysql.jdbc.Driver());

           
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ajp", "root", "");

  
            String query = "SELECT * FROM credit WHERE username = ? AND password = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, userName);
            pst.setString(2, passWord);

         
            ResultSet rs = pst.executeQuery();

           
            if (rs.next()) {
                out.println("<h1>Login Successful!</h1>");
                out.println("<p>Welcome, " + userName + "!</p>");
                out.println("<p>Request Method: " + request.getMethod() + "</p>");
                out.println("<p>Request URL: " + request.getRequestURL() + "</p>");
                out.println("<p>Client IP Address: " + request.getRemoteAddr() + "</p>");
            } else {
                out.println("<h1>Login Failed</h1>");
                out.println("<p>Invalid Username or Password.</p>");
            }

       
            rs.close();
            pst.close();
            con.close();

        } catch (Exception e) {
            out.println("<h1>Error</h1>");
            out.println("<p>" + e.getMessage() + "</p>");
        }
    }
}

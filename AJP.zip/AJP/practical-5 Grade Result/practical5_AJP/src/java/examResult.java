import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

@WebServlet(urlPatterns = {"/examResult"})
public class examResult extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        String studentId = (String) session.getAttribute("studentId");
        String name = (String) session.getAttribute("studentName");
        String department = (String) session.getAttribute("department");


        Cookie[] cookies = request.getCookies();
        String cookieName = "Student";
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("studentName")) {
                cookieName = cookie.getValue();
                break;
            }
        }

        int[] marks = new int[6];
        int totalMarks = 0;

        try {
            for (int i = 0; i < 6; i++) {
                marks[i] = Integer.parseInt(request.getParameter("subj" + (i + 1)));
                totalMarks += marks[i];
            }
        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid input for marks.");
            return;
        }

        float percentage = totalMarks / 6.0f;
        String result = (percentage >= 60) ? "PASS" : "FAIL";
        String color = (percentage >= 60) ? "green" : "red";

        try (PrintWriter out = response.getWriter()) {

            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_grading_system", "root", "");

          
            String insertQuery = "INSERT INTO grades (student_id, subject1, subject2, subject3, subject4, subject5, subject6, total, percentage, result) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setString(1, studentId);
            for (int i = 0; i < 6; i++) {
                ps.setInt(i + 2, marks[i]);
            }
            ps.setInt(8, totalMarks);
            ps.setFloat(9, percentage);
            ps.setString(10, result);
            ps.executeUpdate();

         
            String selectQuery = "SELECT s.name, s.department, g.* FROM students s JOIN grades g ON s.student_id = g.student_id WHERE s.student_id = ?";
            ps = con.prepareStatement(selectQuery);
            ps.setString(1, studentId);
            ResultSet rs = ps.executeQuery();

            out.println("<!DOCTYPE html>");
            out.println("<html><head><title>Exam Result</title>");
            out.println("<style>table {border-collapse: collapse; width: 50%;} th, td {border: 1px solid black; padding: 8px; text-align: center;} </style>");
            out.println("</head><body>");
            out.println("<h1>Welcome, " + cookieName + "</h1><hr>");

            if (rs.next()) {
                out.println("<h2>Student ID: " + rs.getString("student_id") + "</h2>");
                out.println("<h2>Student Name: " + rs.getString("name") + "</h2>");
                out.println("<h2>Department: " + rs.getString("department") + "</h2>");
                out.println("<h3 style='color:" + color + "'>Result: " + rs.getString("result") + "</h3>");
                out.println("<table>");
                out.println("<tr><th>Subject</th><th>Marks</th></tr>");
                for (int i = 1; i <= 6; i++) {
                    out.println("<tr><td>Subject " + i + "</td><td>" + rs.getInt("subject" + i) + "</td></tr>");
                }
                out.println("<tr><th>Total Marks</th><td>" + rs.getInt("total") + "</td></tr>");
                out.println("<tr><th>Percentage</th><td>" + rs.getFloat("percentage") + "%</td></tr>");
                out.println("<tr><th>Result</th><td style='color:" + color + ";'><b>" + rs.getString("result") + "</b></td></tr>");
                out.println("</table>");
            } else {
                out.println("<h3>No record found for student ID: " + studentId + "</h3>");
            }

            out.println("</body></html>");
            con.close();
        } catch (Exception e) {
            response.getWriter().println("Database Error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}












/*import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/examResult"})
public class examResult extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Get marks from the form
        String studentId = request.getParameter("studentId");
        int[] marks = new int[6];
        int totalMarks = 0;

        try {
            for (int i = 0; i < 6; i++) {
                marks[i] = Integer.parseInt(request.getParameter("subj" + (i + 1)));
                totalMarks += marks[i];
            }
        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid input for marks.");
            return;
        }

        float percentage = totalMarks / 6.0f;
        String result = (percentage >= 60) ? "PASS" : "FAIL";
        String color = (percentage >= 60) ? "green" : "red";

        try (PrintWriter out = response.getWriter()) {
            // Database connection setup
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_grading_system", "root", "");

            // Insert the grades data into the grades table
            String insertQuery = "INSERT INTO grades (student_id, subject1, subject2, subject3, subject4, subject5, subject6, total, percentage, result) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setString(1, studentId);
            for (int i = 0; i < 6; i++) {
                ps.setInt(i + 2, marks[i]);
            }
            ps.setInt(8, totalMarks);
            ps.setFloat(9, percentage);
            ps.setString(10, result);
            ps.executeUpdate();

            // Fetch student and grades data
            String selectQuery = "SELECT s.name, s.department, g.* FROM students s JOIN grades g ON s.student_id = g.student_id WHERE s.student_id = ?";
            ps = con.prepareStatement(selectQuery);
            ps.setString(1, studentId);
            ResultSet rs = ps.executeQuery();

            out.println("<!DOCTYPE html>");
            out.println("<html><head><title>Exam Result</title>");
            out.println("<style>table {border-collapse: collapse; width: 50%;} th, td {border: 1px solid black; padding: 8px; text-align: center;} </style>");
            out.println("</head><body>");

            if (rs.next()) {
                out.println("<h1>Student ID: " + rs.getString("student_id") + "</h1>");
                out.println("<h1>Student Name: " + rs.getString("name") + "</h1>");
                out.println("<h2>Department: " + rs.getString("department") + "</h2>");
                out.println("<h3 style='color:" + color + "'>Result: " + rs.getString("result") + "</h3>");
                out.println("<table>");
                out.println("<tr><th>Subject</th><th>Marks</th></tr>");
                for (int i = 1; i <= 6; i++) {
                    out.println("<tr><td>Subject " + i + "</td><td>" + rs.getInt("subject" + i) + "</td></tr>");
                }
                out.println("<tr><th>Total Marks</th><td>" + rs.getInt("total") + "</td></tr>");
                out.println("<tr><th>Percentage</th><td>" + rs.getFloat("percentage") + "%</td></tr>");
                out.println("<tr><th>Result</th><td style='color:" + (rs.getString("result").equalsIgnoreCase("PASS") ? "green" : "red") + ";'><b>" + rs.getString("result") + "</b></td></tr>");
                out.println("</table>");
            } else {
                out.println("<h3>No record found for student ID: " + studentId + "</h3>");
            }

            out.println("</body></html>");
            con.close();
        } catch (Exception e) {
            response.getWriter().println("Database Error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}*/


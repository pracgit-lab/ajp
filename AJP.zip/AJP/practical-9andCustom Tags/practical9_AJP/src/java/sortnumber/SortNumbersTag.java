
package sortnumber;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import javax.servlet.jsp.JspWriter;

public class SortNumbersTag extends SimpleTagSupport {
    private String numbers;
    private String order;

    public void setNumbers(String numbers) {
        this.numbers = numbers;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public void doTag() throws JspException, IOException {
        JspWriter out = getJspContext().getOut();

        // Validate input
        if (numbers == null || numbers.trim().isEmpty()) {
            out.print("<span style='color:red;'>Please enter 10 numbers!</span>");
            return;
        }

        String[] numStrArray = numbers.split(",");
        if (numStrArray.length != 10) {
            out.print("<span style='color:red;'>You must enter exactly 10 numbers!</span>");
            return;
        }

        Integer[] numArray = new Integer[10];

        try {
            for (int i = 0; i < 10; i++) {
                numArray[i] = Integer.parseInt(numStrArray[i].trim());
            }
        } catch (NumberFormatException e) {
            out.print("<span style='color:red;'>Invalid input! Only numbers are allowed.</span>");
            return;
        }

        // Sorting logic
        if ("desc".equalsIgnoreCase(order)) {
            Arrays.sort(numArray, Collections.reverseOrder());  // Descending order
        } else {
            Arrays.sort(numArray);  // Default to ascending
        }

        // Output sorted numbers
        out.print("<strong>Sorted Numbers (" + order.toUpperCase() + "):</strong> ");
        out.print(Arrays.toString(numArray).replaceAll("[\\[\\]]", "")); // Remove brackets from output
    }
}


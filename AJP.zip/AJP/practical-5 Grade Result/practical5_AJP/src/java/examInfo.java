import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

@WebServlet(urlPatterns = {"/examInfo"})
public class examInfo extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        String studentId = request.getParameter("id");
        String department = request.getParameter("department");

        HttpSession session = request.getSession();
        session.setAttribute("studentName", name);
        session.setAttribute("studentId", studentId);
        session.setAttribute("department", department);


        Cookie nameCookie = new Cookie("studentName", name);
        nameCookie.setMaxAge(60 * 60);
        response.addCookie(nameCookie);

        try (PrintWriter out = response.getWriter()) {
            try {
         
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_grading_system", "root", "");

       
                String query = "INSERT INTO students (student_id, name, department) VALUES (?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, studentId);
                ps.setString(2, name);
                ps.setString(3, department);
                ps.executeUpdate();
                con.close();
            } catch (Exception e) {
                response.getWriter().println("Database Error: " + e.getMessage());
                return;
            }

       
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Exam Info</title></head>");
            out.println("<body>");
            out.println("<h1>Welcome, " + name + "</h1><hr>");
            out.println("<form action='examResult' method='POST'>");
            out.println("<center><b>Enter marks for six subjects [out of 100]</b></center><br>");
            for (int i = 1; i <= 6; i++) {
                out.println("Enter marks for subject " + i + " <input type='number' name='subj" + i + "' required><br><br>");
            }
            out.println("<input type='submit' value='Generate Result'>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}















/*import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet(urlPatterns = {"/examInfo"})
public class examInfo extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        String studentId = request.getParameter("id");
        String department = request.getParameter("department");

        try (PrintWriter out = response.getWriter()) {
            try {
                // Database connection setup
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_grading_system", "root", "");

                // Insert student data into database
                String query = "INSERT INTO students (student_id, name, department) VALUES (?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, studentId);
                ps.setString(2, name);
                ps.setString(3, department);
                ps.executeUpdate();
                con.close();
            } catch (Exception e) {
                response.getWriter().println("Database Error: " + e.getMessage());
                return;
            }

            // Display the form for entering marks
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head><title>Exam Info</title></head>");
            out.println("<body>");
            out.println("<form action='examResult' method='POST'>");
            out.println("<h1>Student: " + name + "</h1><br><hr>");
            out.println("<center><b>Enter marks for six subjects [out of 100]</b></center><br>");
            for (int i = 1; i <= 6; i++) {
                out.println("Enter marks for subject " + i + " <input type='number' name='subj" + i + "' required><br><br>");
            }
            out.println("<input type='hidden' name='studentId' value='" + studentId + "'>");
            out.println("<input type='submit' value='Generate Result'>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}

*/
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servlet_1")
public class Servlet_1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String birthDate = request.getParameter("birthDate");
        String email_id = request.getParameter("email_id");
        String phone_no = request.getParameter("phone_no");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/userdb", "root", "");
            String query = "INSERT INTO users (name, birthDate, email_id, phone_no) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, birthDate);
            pstmt.setString(3, email_id);
            pstmt.setString(4, phone_no);

            if (pstmt.executeUpdate() > 0) {
                response.sendRedirect(request.getContextPath() + "/Servlet_2");
            } else {
                out.println("<p style='color:red;'>Unable to Enter Data</p>");
            }

            pstmt.close();
            con.close();
        } catch (SQLException | ClassNotFoundException e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }
    }
}
